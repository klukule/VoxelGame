﻿
namespace VoxelGame.Blocks
{
    /// <summary>
    /// Base log block
    /// </summary>
    public class LogBlock : Block
    {
    }
}
